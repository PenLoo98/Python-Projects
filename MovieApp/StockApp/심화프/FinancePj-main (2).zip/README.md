# FinancePj
PER 기반 종목 추천, finBERT 뉴스 분석
